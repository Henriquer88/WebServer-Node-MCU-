//***********************Teste Web Server Mortores V00******************************//

//*********************************************************************************//


#include "mbed.h"
#include "ssd1306.h"

Serial esp(D8, D2, 115200); // TX , RX
Serial pc(USBTX, USBRX , 115200);
#define velocidade (3)

DigitalOut in1_m1 (PA_8);
DigitalOut in2_m1 (PC_7);
DigitalOut in3_m1 (PB_6);
DigitalOut in4_m1 (PA_7);
AnalogIn  pot       (A0);

SSD1306 lcd (D14, D15); // assumes default I2C address of 0x78

DigitalOut in1_m3 (PC_4);
DigitalOut in2_m3 (PB_13);
DigitalOut in3_m3 (PB_14);
DigitalOut in4_m3 (PB_15);

//BusOut MPX(PA_8,PC_7,PB_6,PA_7); //X

//BusOut MPZ(PC_4,PB_13,PB_14,PB_15); //Z

//BusOut MPY(PB_3,PB_5,PB_4,PB_10); //Y



DigitalOut in1_m2(PB_3);
DigitalOut in2_m2(PB_5);
DigitalOut in3_m2(PB_4);
DigitalOut in4_m2(PB_10);

DigitalOut rele (PA_6);

int main()
{


    lcd.speed (SSD1306::Medium);  // set working frequency
    lcd.set_contrast(100);
    lcd.cls();
    lcd.locate (2,5);             // set text cursor to line 3, column 1
    lcd.printf ("INSPER"); // print to frame buffer
    lcd.init();                   // initialize SSD1306
    lcd.redraw();

    while(1) {


       
        // x_pot = pot.read()*1000;

        //esp.printf(" %4d\r\n", x_pot );
         //pc.printf(" %4d\r\n", x_pot );
         //wait(1);

         if(esp.readable()) {
            char c = esp.getc();
            pc.printf(" %c\r\n", c);



         if (c == '1'){
        
//*********************************MOTOR X  Horário  **********************************************//
                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Motor X"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Horario"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
             for (int i= 0; i<1024;i++){// Motor gira duas vezes no sentido horário

                in1_m1 = 1 ;
                in2_m1 = 0;
                in3_m1 = 0;
                in4_m1 = 0 ;
                wait_ms(velocidade);

                in1_m1 = 0 ;
                in2_m1 = 1;
                in3_m1 = 0;
                in4_m1 = 0 ;
                
                wait_ms(velocidade);

                in1_m1 = 0 ;
                in2_m1 = 0;
                in3_m1 = 1;
                in4_m1 = 0 ;

                wait_ms(velocidade);

                in1_m1 = 0 ;
                in2_m1 = 0;
                in3_m1 = 0;
                in4_m1 = 1;

                wait_ms(velocidade);

            }
         }
        
//*********************************************************************************************************//

//*********************************MOTOR X   Anti Horário  **********************************************//

         wait(0.1);

         if (c == '2'){

                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Motor X"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Anti Horario"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();

        

            for( int i= 0; i<1024;i++){ // Motor gira duas vezes no sentido Anti horário

                in1_m1 = 0 ;
                in2_m1 = 0;
                in3_m1 = 0;
                in4_m1 = 1;

                wait_ms(velocidade);

                in1_m1 = 0;
                in2_m1 = 0;
                in3_m1 = 1;
                in4_m1 = 0 ;
                
                wait_ms(velocidade);

                in1_m1 = 0 ;
                in2_m1 = 1;
                in3_m1 = 0;
                in4_m1 = 0 ;

                wait_ms(velocidade);

                in1_m1 = 1;
                in2_m1 = 0;
                in3_m1 = 0;
                in4_m1 = 0;

                wait_ms(velocidade);

            }

         }

//*********************************************************************************************************/

         wait(0.1);
        


//********************************* MOTOR Y Horário  **********************************************//


         if (c == '3'){
        
                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Motor Y"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Horario"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
            for( int i=0; i<1024;i++){ // Aciona os três motores  no sentido horário

                in1_m2 =1;
                in2_m2 =0;
                in3_m2 =0;
                in4_m2 =0;
               
                wait_ms(velocidade);

                in1_m2 =0;
                in2_m2= 1;
                in3_m2 =0;
                in4_m2= 0;

                wait_ms(velocidade);

                in1_m2 = 0;
                in2_m2 = 0;
                in3_m2 = 1;
                in4_m2 = 0;

                wait_ms(velocidade);

                in1_m2 = 0;
                in2_m2 = 0;
                in3_m2 = 0;
                in4_m2 = 1;

                wait_ms(velocidade);

            }

         }

//*********************************************************************************************************//

//********************************* MOTOR Y Anti  Horário  ************************************************//
         if (c == '4'){
        
                lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Motor Y"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Anti Horario"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
            for( int i=0; i<1024;i++){ // Aciona os três motores  no sentido horário

                in1_m2 =0;
                in2_m2 =0;
                in3_m2 =0;
                in4_m2 =1;
               
                wait_ms(velocidade);

                in1_m2 =0;
                in2_m2= 0;
                in3_m2 =1;
                in4_m2= 0;

                wait_ms(velocidade);

                in1_m2 = 0;
                in2_m2 = 1;
                in3_m2 = 0;
                in4_m2 = 0;

                wait_ms(velocidade);

                in1_m2 = 1;
                in2_m2 = 0;
                in3_m2 = 0;
                in4_m2 = 0;

                wait_ms(velocidade);

            }

         }
//*********************************************************************************************************//

//********************************* MOTOR Z  Horário  *****************************************************//

         if (c == '5'){
        
                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Motor Z"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Horario"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
            for( int i=0; i<1024;i++){ // Aciona os três motores  no sentido horário

                in1_m3 =1;
                in2_m3 =0;
                in3_m3 =0;
                in4_m3 =0;
               
                wait_ms(velocidade);

                in1_m3 =0;
                in2_m3= 1;
                in3_m3 =0;
                in4_m3= 0;

                wait_ms(velocidade);

                in1_m3 = 0;
                in2_m3 = 0;
                in3_m3 = 1;
                in4_m3 = 0;

                wait_ms(velocidade);

                in1_m3 = 0;
                in2_m3 = 0;
                in3_m3 = 0;
                in4_m3 = 1;

                wait_ms(velocidade);

            }

         }

         wait(0.1);
//**************************************************************************************************************//

//********************************* MOTOR Z  Anti Horário  *****************************************************//
         if (c == '6'){
        
                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Motor Z"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Anti Horario"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
                  
            for( int i=0; i<1024;i++){ // Aciona os três motores  no sentido horário

                in1_m3 =0;
                in2_m3 =0;
                in3_m3 =0;
                in4_m3 =1;
               
                wait_ms(velocidade);

                in1_m3 =0;
                in2_m3= 0;
                in3_m3 =1;
                in4_m3= 0;

                wait_ms(velocidade);

                in1_m3 = 0;
                in2_m3 = 1;
                in3_m3 = 0;
                in4_m3 = 0;

                wait_ms(velocidade);

                in1_m3 = 1;
                in2_m3 = 0;
                in3_m3 = 0;
                in4_m3 = 0;

                wait_ms(velocidade);

            }

         }
//*******************************************************************************************************************//

//***************************************** Acionameto do Relê *******************************************************//

         wait(0.1);

            if(c == '7'){

                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Estado do Rele"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Ligado"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
                 // lcd.cls();
             rele=0;

            }

            if(c == '8'){

                  lcd.locate (3,1);             // set text cursor to line 3, column 1
                  lcd.printf ("Estado do Rele"); // print to frame buffer
                  lcd.locate (4,1); 
                  lcd.printf (" Desligado"); // print to frame buffer
                  lcd.init();  
                  lcd.redraw();
                  //lcd.cls();
             rele=1;

            }

            lcd.cls();

//*******************************************************************************************************************//

        }

    }
}
